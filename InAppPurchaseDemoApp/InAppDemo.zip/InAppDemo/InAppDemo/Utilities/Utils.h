//
//  Utils.h
//  InAppDemo
//
//  Created by Abhishek Kumar Ravi on 12/04/16.
//  Copyright © 2016 Abhishek Kumar Ravi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Utils : NSObject

+(BOOL)isInternetAvailable;

@end
