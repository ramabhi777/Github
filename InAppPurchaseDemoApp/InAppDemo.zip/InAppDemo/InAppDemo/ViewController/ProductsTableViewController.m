//
//  ProductsTableViewController.m
//  InAppDemo
//
//  Created by Abhishek Kumar Ravi on 29/02/16.
//  Copyright © 2016 Abhishek Kumar Ravi. All rights reserved.
//

#import "ProductsTableViewController.h"

@implementation ProductsTableViewController

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
