//
//  main.m
//  InAppDemo
//
//  Created by Abhishek Kumar Ravi on 29/02/16.
//  Copyright © 2016 Abhishek Kumar Ravi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
